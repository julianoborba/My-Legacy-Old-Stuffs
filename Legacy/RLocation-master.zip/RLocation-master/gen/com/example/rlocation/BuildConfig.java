/** Automatically generated file. DO NOT MODIFY */
package com.example.rlocation;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}