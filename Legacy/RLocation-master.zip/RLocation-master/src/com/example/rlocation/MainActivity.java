package com.example.rlocation;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.http.conn.util.InetAddressUtils;

import android.app.Activity;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {

	private boolean isStarted;
	private MyServer myServerThread;

	class MyServer extends Thread implements Runnable {
		@Override
		public void run() {
			int port = 8080;
			ServerSocket serverSocket = null;
			try {
				serverSocket = new ServerSocket(port);
			} catch (IOException e) {
				Log.e("RLocation", "Erro : " + e.getMessage());
			}
			while (!isInterrupted()) {
				try {
					List<SMSData> smsList = new ArrayList<SMSData>();
					Uri uri = Uri.parse("content://sms/inbox");
					Cursor c = getContentResolver().query(uri, null, null, null, null);
					if (c.moveToFirst()) {
						for (int i = 0; i < c.getCount(); i++) {
							if (c.getString(c.getColumnIndexOrThrow("body")).toString().startsWith("[NLocation]")) {
								SMSData sms = new SMSData();
								String body = "";
								body += "<html>";
								body += "<head>";
								body += "<script>function pageRefresh() {setTimeout(\"window.location.reload(true)\",15000);}</script>";
								body += "<title>RLocation for " + c.getString(c.getColumnIndexOrThrow("address")).toString() + "</title>";
								body += "</head>";
								body += "<frameset onload=\"pageRefresh()\" border=\"0\" cols=\"100%\">";
								body += "<frame src=\"" + c.getString(c.getColumnIndexOrThrow("body")).toString().replace("[NLocation]", "") + "\" name=\"Maps\" noresize target=\"main\">";
								body += "<noframes>";
								body += "<body>";
								body += "</body>";
								body += "</noframes>";
								body += "</frameset>";
								body += "</html>";
								sms.setBody(body);
								sms.setNumber(c.getString(c.getColumnIndexOrThrow("address")).toString());
								smsList.add(sms);
							}
							if (c.isLast()) {
								c.moveToNext();
							} else {
								break;
							}
						}
					}
					c.close();
					String maps = smsList.get(smsList.size()-1).getBody();
					Socket clientSocket = serverSocket.accept();
					BufferedWriter out = new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream()));
					out.write("HTTP/1.1 200 OK\r\n");
					out.write("Content-Type: text/html\r\n");
					Date date = new Date();
					Calendar calendar = Calendar.getInstance();
					calendar.setTime(date);
					calendar.add(Calendar.MINUTE, 1);
					out.write("Expires: " + new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss zzz").format(calendar.getTime()) + " GMT\r\n");
					out.write("\r\n");
					out.write(maps);
					out.flush();
					clientSocket.shutdownOutput();
					clientSocket.close();
				} catch (IOException e) {
					Log.e("RLocation", "Erro : " + e.getMessage());
				} catch (IndexOutOfBoundsException e) {
					Log.e("RLocation", "Erro : " + e.getMessage());
				} catch (NullPointerException e) {
					Log.e("RLocation", "Erro : " + e.getMessage());
				}
			}
			try {
				serverSocket.close();
			} catch (IOException e) {
				Log.e("RLocation", e.getMessage());
			}
			return;
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		final TextView txtAddr = (TextView) findViewById(R.id.txtAddr);
		final TextView isActive = (TextView) findViewById(R.id.lblIsActive);
		final Button btnStart = (Button) findViewById(R.id.btnStart);
		final Button btnStop = (Button) findViewById(R.id.btnStop);
		isActive.setTextColor(Color.RED);
		btnStop.setEnabled(false);
		btnStart.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if (!isStarted) {
					isStarted = true;
					btnStart.setEnabled(false);
					btnStop.setEnabled(true);
					isActive.setText("Active");
					isActive.setTextColor(Color.BLUE);
					myServerThread = new MyServer();
					myServerThread.start();
					txtAddr.setText("URL: http://" + getIPAddress(true) + ":8080");
				}
			}
		});
		btnStop.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if (isStarted) {
					isStarted = false;
					btnStart.setEnabled(true);
					btnStop.setEnabled(false);
					isActive.setText("Inactive");
					isActive.setTextColor(Color.RED);
					myServerThread.interrupt();
					myServerThread = null;
					txtAddr.setText("URL:");
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	public void generateTextFileOnSD(String sFileName, String sBody) {
		try {
			String state = Environment.getExternalStorageState();
			boolean mExternalStorageAvailable;
			if (Environment.MEDIA_MOUNTED.equals(state)) {
				mExternalStorageAvailable = true;
			} else {
				mExternalStorageAvailable = false;
			}
			if (mExternalStorageAvailable) {
				File root = new File(Environment.getExternalStorageDirectory(), "RLocation");
				if (!root.exists()) {
					root.mkdirs();
				}
				File htmlFile = new File(root, sFileName);
				FileWriter writer = new FileWriter(htmlFile, false);
				writer.append(sBody);
				writer.flush();
				writer.close();
			}
		} catch (IOException e) {
			Log.e("RLocation", "Erro : " + e.getMessage());
		}
	}
	
	public static String getIPAddress(boolean useIPv4) {
		try {
			List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
			for (NetworkInterface intf : interfaces) {
				List<InetAddress> addrs = Collections.list(intf.getInetAddresses());
				for (InetAddress addr : addrs) {
					if (!addr.isLoopbackAddress()) {
						String sAddr = addr.getHostAddress().toUpperCase();
						boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
						if (useIPv4) {
							if (isIPv4)
								return sAddr;
						} else {
							if (!isIPv4) {
								int delim = sAddr.indexOf('%');
								return delim < 0 ? sAddr : sAddr.substring(0, delim);
							}
						}
					}
				}
			}
		} catch (Exception e) {
			Log.e("RLocation", "Erro : " + e.getMessage());
		}
		return "";
	}
}