package br.juliano.mybluime;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.inputmethodservice.InputMethodService;
import android.os.Environment;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.widget.Toast;
import br.juliano.ime.R;

public class MyBluImeActivity extends InputMethodService {

	private BufferedReader reader;
	private BufferedReader errReader;
	private Process process;
	private boolean isDestroyed;
	private boolean mExternalStorageWriteable;
	// private boolean mExternalStorageAvailable;
	// private BluetoothAdapter bluetoothAdapter;
	
	private boolean isShiftOn = false;
	private boolean isAltOn = false;
	private boolean isCtrlOn = false;
	private boolean isFnlOn = false;
	private boolean isCapsOn = false;
	private boolean isNumOn = false;

	private boolean keyfound = false;
	private int keyEventCode = 0;
	
	private String keyboardDataRegex = "^[>]\\s\\S\\S\\s\\S\\S\\s\\S\\S\\s\\S\\S\\s\\S\\S\\s\\S\\S\\s\\S\\S\\s\\S\\S\\s\\S\\S\\s\\S\\S$";
	private int keyboardDataLen = 31;
	private int keyboardDataVectorLen = 11;
	
	
	@Override
	public void onCreate() {
		
		super.onCreate();
		installBinary();
		new Thread(newRunnable()).start();
		
	}

	private Runnable newRunnable() {

		return new Runnable() {
			
			public void run() {
				
				if (isDestroyed)
					return;
				try {
					Log.v("MyBluIME", "MyBluIME onCreate() called");
					process = Runtime.getRuntime().exec(new String[] { "su", "-c", "hcidump --raw" });
					reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
					errReader = new BufferedReader(new InputStreamReader(process.getErrorStream()));
					consumeInput();
				} catch (IOException ioException) {
					Log.e("MyBluIME", "Message: " + ioException.getMessage(), ioException);
					throw new RuntimeException(ioException);
				}
				
			}

			private void consumeInput() throws IOException {
				
				String outputString = "";
				// String errString = "";
				while ((outputString = reader.readLine()) != null /*|| (errString = errReader.readLine()) != null*/) {
					keyfound = false;
					try {
						if ( (outputString != null && (outputString.length() >= keyboardDataLen) && (Pattern.matches(keyboardDataRegex, outputString.substring(0, keyboardDataLen)))) ) {
							String[] data = outputString.split(" ");
							if (data.length > keyboardDataVectorLen) {
								String rawKey = "";
								try {
									rawKey = data[12] + " " + data[14] + " " + data[15];
								} catch (ArrayIndexOutOfBoundsException e) {
									continue;
								}
								specialKeys(data);
								averageKeys(data, rawKey);
								keyEventCode = modifierKeys(keyEventCode, keyfound, data);
							}
						}
					} catch (Exception exception) {
						Log.e("MyBluIME", "Message: " + exception.getMessage(), exception);
					}
				}
				
			}

			private void averageKeys(String[] data, String rawKey) {
				
				if (data[12].equals("80")) {
					keyEventCode = KeyEvent.KEYCODE_MENU; // Windows logo
					keyfound = true;
				} else if (data[14].equals("29")) {
					keyEventCode = KeyEvent.KEYCODE_BACK;
					keyfound = true;
				} else if (data[14].equals("3A")) {
					keyEventCode = 131; //KeyEvent.KEYCODE_F1;
					keyfound = false;
				} else if (data[14].equals("3B")) {
					keyEventCode = 132; //KeyEvent.KEYCODE_F2;
					keyfound = false;
				} else if (data[14].equals("3C")) {
					keyEventCode = 133; //KeyEvent.KEYCODE_F3;
					keyfound = false;
				} else if (data[14].equals("3D")) {
					keyEventCode = 134; //KeyEvent.KEYCODE_F4;
					keyfound = false;
				} else if (data[14].equals("3E")) {
					keyEventCode = 135; //KeyEvent.KEYCODE_F5;
					keyfound = false;
				} else if (data[14].equals("3F")) {
					keyEventCode = 136; //KeyEvent.KEYCODE_F6;
					keyfound = false;
				} else if (data[14].equals("40")) {
					keyEventCode = 137; //KeyEvent.KEYCODE_F7;
					keyfound = false;
				} else if (data[14].equals("41")) {
					keyEventCode = 138; //KeyEvent.KEYCODE_F8;
					keyfound = false;
				} else if (data[14].equals("42")) {
					keyEventCode = 139; //KeyEvent.KEYCODE_F9;
					keyfound = false;
				} else if (data[14].equals("43")) {
					keyEventCode = 130; //KeyEvent.KEYCODE_F10;
					keyfound = false;
				} else if (data[14].equals("44")) {
					keyEventCode = 141; //KeyEvent.KEYCODE_F11;
					keyfound = false;
				} else if (data[14].equals("45")) {
					keyEventCode = 142; //KeyEvent.KEYCODE_F12;
					keyfound = false;
				} else if (data[14].equals("46")) {
					// View screen = (View)
					// findViewById(R.id.screen);
					// screen.setDrawingCacheEnabled(true);
					// Bitmap bmScreen =
					// screen.getDrawingCache();
					keyEventCode = 120; //KeyEvent.KEYCODE_SYSRQ;
					keyfound = true;
				} else if (data[14].equals("47")) {
					keyEventCode = 116; //KeyEvent.KEYCODE_SCROLL_LOCK;
					keyfound = true;
				} else if (data[14].equals("48")) {
					keyEventCode = 121; //KeyEvent.KEYCODE_BREAK;
					keyfound = true;
				} else if (data[14].equals("35")) {
					keyEventCode = KeyEvent.KEYCODE_GRAVE;
					keyfound = true;
				} else if (data[14].equals("1E")) {
					keyEventCode = KeyEvent.KEYCODE_1;
					keyfound = true;
				} else if (data[14].equals("1F")) {
					keyEventCode = KeyEvent.KEYCODE_2;
					keyfound = true;
				} else if (data[14].equals("20")) {
					keyEventCode = KeyEvent.KEYCODE_3;
					keyfound = true;
				} else if (data[14].equals("21")) {
					keyEventCode = KeyEvent.KEYCODE_4;
					keyfound = true;
				} else if (data[14].equals("22")) {
					keyEventCode = KeyEvent.KEYCODE_5;
					keyfound = true;
				} else if (data[14].equals("23")) {
					keyEventCode = KeyEvent.KEYCODE_6;
					keyfound = true;
				} else if (data[14].equals("24")) {
					keyEventCode = KeyEvent.KEYCODE_7;
					keyfound = true;
				} else if (data[14].equals("25")) {
					keyEventCode = KeyEvent.KEYCODE_8;
					keyfound = true;
				} else if (data[14].equals("26")) {
					keyEventCode = KeyEvent.KEYCODE_9;
					keyfound = true;
				} else if (data[14].equals("27")) {
					keyEventCode = KeyEvent.KEYCODE_0;
					keyfound = true;
				} else if (data[14].equals("2D")) {
					keyEventCode = KeyEvent.KEYCODE_MINUS;
					keyfound = true;
				} else if (data[14].equals("2E")) {
					keyEventCode = KeyEvent.KEYCODE_EQUALS;
					keyfound = true;
				} else if (data[14].equals("2A")) {
					keyEventCode = KeyEvent.KEYCODE_DEL; // Backspace
					keyfound = true;
				} else if (data[14].equals("4A")) {
					keyEventCode = KeyEvent.KEYCODE_HOME;
					keyfound = true;
				} else if (data[14].equals("2B")) {
					keyEventCode = KeyEvent.KEYCODE_TAB;
					keyfound = true;
				} else if (data[14].equals("14")) {
					keyEventCode = KeyEvent.KEYCODE_Q;
					keyfound = true;
				} else if (data[14].equals("1A")) {
					keyEventCode = KeyEvent.KEYCODE_W;
					keyfound = true;
				} else if (data[14].equals("08")) {
					keyEventCode = KeyEvent.KEYCODE_E;
					keyfound = true;
				} else if (data[14].equals("15")) {
					keyEventCode = KeyEvent.KEYCODE_R;
					keyfound = true;
				} else if (data[14].equals("17")) {
					keyEventCode = KeyEvent.KEYCODE_T;
					keyfound = true;
				} else if (data[14].equals("1C")) {
					keyEventCode = KeyEvent.KEYCODE_Y;
					keyfound = true;
				} else if (data[14].equals("18")) {
					keyEventCode = KeyEvent.KEYCODE_U;
					keyfound = true;
				} else if (data[14].equals("0C")) {
					keyEventCode = KeyEvent.KEYCODE_I;
					keyfound = true;
				} else if (data[14].equals("12")) {
					keyEventCode = KeyEvent.KEYCODE_O;
					keyfound = true;
				} else if (data[14].equals("13")) {
					keyEventCode = KeyEvent.KEYCODE_P;
					keyfound = true;
				} else if (data[14].equals("2F")) {
					keyEventCode = KeyEvent.KEYCODE_LEFT_BRACKET;
					keyfound = true;
				} else if (data[14].equals("30")) {
					keyEventCode = KeyEvent.KEYCODE_RIGHT_BRACKET;
					keyfound = true;
				} else if (data[14].equals("31")) {
					keyEventCode = KeyEvent.KEYCODE_BACKSLASH;
					keyfound = true;
				} else if (data[14].equals("4B")) {
					keyEventCode = 92; //KeyEvent.KEYCODE_PAGE_UP;
					keyfound = true;
				} else if (data[14].equals("04")) {
					keyEventCode = KeyEvent.KEYCODE_A;
					keyfound = true;
				} else if (data[14].equals("16")) {
					keyEventCode = KeyEvent.KEYCODE_S;
					keyfound = true;
				} else if (data[14].equals("07")) {
					keyEventCode = KeyEvent.KEYCODE_D;
					keyfound = true;
				} else if (data[14].equals("09")) {
					keyEventCode = KeyEvent.KEYCODE_F;
					keyfound = true;
				} else if (data[14].equals("0A")) {
					keyEventCode = KeyEvent.KEYCODE_G;
					keyfound = true;
				} else if (data[14].equals("0B")) {
					keyEventCode = KeyEvent.KEYCODE_H;
					keyfound = true;
				} else if (data[14].equals("0D")) {
					keyEventCode = KeyEvent.KEYCODE_J;
					keyfound = true;
				} else if (data[14].equals("0E")) {
					keyEventCode = KeyEvent.KEYCODE_K;
					keyfound = true;
				} else if (data[14].equals("0F")) {
					keyEventCode = KeyEvent.KEYCODE_L;
					keyfound = true;
				} else if (data[14].equals("33")) {
					keyEventCode = KeyEvent.KEYCODE_SEMICOLON;
					keyfound = true;
				} else if (data[14].equals("34")) {
					keyEventCode = KeyEvent.KEYCODE_APOSTROPHE;
					keyfound = true;
				} else if (data[14].equals("28")) {
					keyEventCode = KeyEvent.KEYCODE_ENTER;
					keyfound = true;
				} else if (data[14].equals("4E")) {
					keyEventCode = 93; //KeyEvent.KEYCODE_PAGE_DOWN;
					keyfound = true;
				} else if (data[14].equals("1D")) {
					keyEventCode = KeyEvent.KEYCODE_Z;
					keyfound = true;
				} else if (data[14].equals("1B")) {
					keyEventCode = KeyEvent.KEYCODE_X;
					keyfound = true;
				} else if (data[14].equals("06")) {
					keyEventCode = KeyEvent.KEYCODE_C;
					keyfound = true;
				} else if (data[14].equals("19")) {
					keyEventCode = KeyEvent.KEYCODE_V;
					keyfound = true;
				} else if (data[14].equals("05")) {
					keyEventCode = KeyEvent.KEYCODE_B;
					keyfound = true;
				} else if (data[14].equals("11")) {
					keyEventCode = KeyEvent.KEYCODE_N;
					keyfound = true;
				} else if (data[14].equals("10")) {
					keyEventCode = KeyEvent.KEYCODE_M;
					keyfound = true;
				} else if (data[14].equals("36")) {
					keyEventCode = KeyEvent.KEYCODE_COMMA;
					keyfound = true;
				} else if (data[14].equals("37")) {
					keyEventCode = KeyEvent.KEYCODE_PERIOD;
					keyfound = true;
				} else if (data[14].equals("38")) {
					keyEventCode = KeyEvent.KEYCODE_SLASH;
					keyfound = true;
				} else if (data[14].equals("52")) {
					keyEventCode = KeyEvent.KEYCODE_DPAD_UP;
					keyfound = true;
				} else if (data[14].equals("4D")) {
					keyEventCode = 123; //KeyEvent.KEYCODE_MOVE_END;
					keyfound = true;
				} else if (data[14].equals("2C")) {
					keyEventCode = KeyEvent.KEYCODE_SPACE;
					keyfound = true;
				} else if (data[14].equals("65")) {
					keyEventCode = KeyEvent.KEYCODE_MENU;
					keyfound = true;
				} else if (data[14].equals("49")) {
					keyEventCode = 124; //KeyEvent.KEYCODE_INSERT;
					keyfound = true;
				} else if (data[14].equals("4C")) {
					keyEventCode = 112; //KeyEvent.KEYCODE_FORWARD_DEL;
					keyfound = true;
				} else if (data[14].equals("50")) {
					keyEventCode = KeyEvent.KEYCODE_DPAD_LEFT;
					keyfound = true;
				} else if (data[14].equals("51")) {
					keyEventCode = KeyEvent.KEYCODE_DPAD_DOWN;
					keyfound = true;
				} else if (data[14].equals("4F")) {
					keyEventCode = KeyEvent.KEYCODE_DPAD_RIGHT;
					keyfound = true;
				} else if (data[14].equals("00")) {
					keyfound = false;
					Log.v("MyBluIME", "MyBluIME key 00 found, last key will be used now : " + keyEventCode);
				} else {
					keyfound = false;
					Log.v("MyBluIME", "MyBluIME key not found : " + rawKey + " [?]");
				}
				
			}

			private int modifierKeys(int keyEventCode, boolean keyfound, String[] data) {
				
				if (keyfound && data[15].equals("00")) {
					if (isShiftOn) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_DOWN, keyEventCode, 0, KeyEvent.META_SHIFT_LEFT_ON, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isAltOn) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_DOWN, keyEventCode, 0, KeyEvent.META_ALT_LEFT_ON, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isCtrlOn) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_DOWN, keyEventCode, 0, 0x2000 /*KeyEvent.META_CTRL_LEFT_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isFnlOn) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_DOWN, keyEventCode, 0, 0x8 /*KeyEvent.META_FUNCTION_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isCapsOn) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_DOWN, keyEventCode, 0, 0x100000 /*KeyEvent.META_CAPS_LOCK_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isNumOn) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_DOWN, keyEventCode, 0, 0x200000 /*KeyEvent.META_NUM_LOCK_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_DOWN, keyEventCode, 0, 0, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					}
				} else {
					if (isShiftOn && keyEventCode != 0) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyEventCode, 0, KeyEvent.META_SHIFT_LEFT_ON, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isAltOn && keyEventCode != 0) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyEventCode, 0, KeyEvent.META_ALT_LEFT_ON, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isCtrlOn && keyEventCode != 0) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyEventCode, 0, 0x2000 /*KeyEvent.META_CTRL_LEFT_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isFnlOn && keyEventCode != 0) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyEventCode, 0, 0x8 /*KeyEvent.META_FUNCTION_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isCapsOn && keyEventCode != 0) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyEventCode, 0, 0x100000 /*KeyEvent.META_CAPS_LOCK_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else if (isNumOn && keyEventCode != 0) {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyEventCode, 0, 0x200000 /*KeyEvent.META_NUM_LOCK_ON*/, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					} else {
						getCurrentInputConnection().sendKeyEvent(new KeyEvent(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), KeyEvent.ACTION_UP, keyEventCode, 0, 0, 0, 0, KeyEvent.FLAG_SOFT_KEYBOARD | KeyEvent.FLAG_KEEP_TOUCH_MODE));
					}
					keyEventCode = 0;
				}
				return keyEventCode;
				
			}

			private void specialKeys(String[] data) {
				
				if (data[12].equals("02")) {
					// KeyEvent.KEYCODE_SHIFT_LEFT;
					isShiftOn = true;
				} else if (data[12].equals("40")) {
					// KeyEvent.KEYCODE_ALT_RIGHT;
					isAltOn = true;
				} else if (data[12].equals("20")) {
					// KeyEvent.KEYCODE_SHIFT_RIGHT;
					isShiftOn = true;
				} else if (data[12].equals("01")) {
					// KeyEvent.KEYCODE_CTRL_LEFT;
					isCtrlOn = true;
				} else if (data[12].equals("04")) {
					// KeyEvent.KEYCODE_ALT_LEFT;
					isAltOn = true;
				} else if (data[12].equals("10")) {
					// KeyEvent.KEYCODE_FUNCTION;
					isFnlOn = true;
				} else if (data[14].equals("53")) {
					// KeyEvent.KEYCODE_NUM_LOCK;
					isNumOn = true;
				} else if (data[14].equals("39")) {
					// KeyEvent.KEYCODE_CAPS_LOCK;
					isCapsOn = true;
				} else if (data[12].equals("00") || data[14].equals("00")) {
					setFlasgToFalse();
				}
				
			}

			private void setFlasgToFalse() {
				
				isShiftOn = false;
				isAltOn = false;
				isCtrlOn = false;
				isFnlOn = false;
				isCapsOn = false;
				isNumOn = false;
				
			}
		};
	}

	private void installBinary() {
		if (!new File("/system/xbin/hcidump").exists()) {
			ensureFile(R.raw.hcidump, "hcidump");
			Toast.makeText(this, "hcidump have been installed!", Toast.LENGTH_SHORT).show();
		}
	}

	@Override
	public void onDestroy() {
		
		super.onDestroy();
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setMessage("Finish MyBluIME?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				try {
					isDestroyed = true;
					Log.v("MyBluIME", "MyBluIME closed and destroyed");
					reader.close();
					errReader.close();
					process.destroy();
				} catch (IOException ioException) {
					Log.e("MyBluIME", "Message: " + ioException.getMessage(), ioException);
					throw new RuntimeException(ioException);
				}
			}
		}).setNegativeButton("No", new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialog, int id) {
				dialog.cancel();
			}
		});
		builder.create();
		
	}

	private void ensureFile(int paramInt, String paramString) {
		
		String str1 = "<sdcard not available>" + paramString;
		String str2 = "/system/xbin/" + paramString;
		try {
			updateExternalStorageState();
			if (this.mExternalStorageWriteable) {
				str1 = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + paramString;
			}
			Log.i(toString(), "MyBluActivity.ensureFile(int id, String file): File not found: " + str2);
			InputStream localInputStream = getResources().openRawResource(paramInt);
			byte[] arrayOfByte = new byte[localInputStream.available()];
			localInputStream.read(arrayOfByte);
			localInputStream.close();
			FileOutputStream localFileOutputStream = new FileOutputStream(str1);
			localFileOutputStream.write(arrayOfByte);
			localFileOutputStream.close();
			execCommandLine("mount -o rw,remount /system");
			execCommandLine("cp " + str1 + " " + str2);
			execCommandLine("rm " + str1);
		} catch (IOException localIOException) {
			Toast.makeText(this, "This application needs root permissions and BusyBox!", Toast.LENGTH_LONG).show();
		}
		
	}

	private void updateExternalStorageState() {
		
//		String str = Environment.getExternalStorageState();
//		if ("mounted".equals(str)) {
//			mExternalStorageWriteable = true;
//			mExternalStorageAvailable = true;
//		}
//		if ("mounted_ro".equals(str)) {
//			mExternalStorageAvailable = true;
//			mExternalStorageWriteable = false;
//		}
//		mExternalStorageWriteable = false;
//		mExternalStorageAvailable = false;
		
	}

	private int execCommandLine(String paramString) {
		
		int i = 0;
		try {
			Process localProcess = Runtime.getRuntime().exec("su");
			DataOutputStream localDataOutputStream = new DataOutputStream(localProcess.getOutputStream());
			if (paramString != null && !paramString.equals("")) {
				localDataOutputStream.writeBytes(paramString + "\n");
				localDataOutputStream.writeBytes("exit\n");
				localDataOutputStream.flush();
			}
			i = localProcess.waitFor();
			localDataOutputStream.close();
		} catch (IOException localIOException) {
			Log.e("MyBluActivity.execCommandLine(String paramString):", " " + localIOException.getMessage());
		} catch (InterruptedException interruptedException) {
			Log.e("MyBluActivity.execCommandLine(String paramString):", " " + interruptedException.getMessage());
		}
		return i;
		
	}

	@Override
	public boolean onKeyUp(int keyCode, KeyEvent event) {
		return super.onKeyUp(keyCode, event);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		return super.onKeyDown(keyCode, event);
	}

}