** From the legacy stuff along my way as Java programmer **


MyBluIme
========

It is an app used to patch the Android issue what, even connected, the bluetooth keyboard don't writes.... So this app bring to you an solution to use your bluetooth keyboard connected at the Android, the keyboard don't get connected at the app like the market apps, so it don't lost connection (I'm assuming what you won't run away from the device). Is just install, and set as your IME.

* 0 - Turn on Bluetooth on your Android;
* 1 - Pair your keyboard with your Android and connect it;
* 2 - Open the menu and go to input options, enable MyBluIME and select to use;
* 3 - If your Android does not have the necessary system files, the app will install, just wait - is needed allow superuser (aka root) and have Busybox installed;
* 4 - Try to write at an notepad.
