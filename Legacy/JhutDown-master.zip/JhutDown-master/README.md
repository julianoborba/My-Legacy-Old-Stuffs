** From the legacy stuff along my way as Java programmer **


JhutDown
========

Think about someone that always forget the PC turned-on... so half of your energy bill came from a single silly computer... why you don't try JhutDown?

JhutDown automatically turns off your computer if it detect that your system are lazy.
