package br.juliano.control;

import java.io.IOException;
import java.util.Timer;
import java.util.TimerTask;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;
import org.jnativehook.mouse.NativeMouseEvent;
import org.jnativehook.mouse.NativeMouseInputListener;
import org.jnativehook.mouse.NativeMouseWheelEvent;
import org.jnativehook.mouse.NativeMouseWheelListener;

public class Main implements NativeMouseInputListener, NativeMouseWheelListener, NativeKeyListener {

	private static int waiter; // in seconds

	public static void main(String[] args) {
		registerNativeHook();
		setTimer();
	}

	private static Timer setTimer() {
		Timer timer = new Timer();
		timer.scheduleAtFixedRate(new TimerTask() {
			@Override
			public void run() {
				waiter++;
				if (waiter >= 2400) { // 2400 sec = 40 min
					try {
						shutdown();
					} catch (RuntimeException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					} catch (NativeHookException e) {
						e.printStackTrace();
					}
				}
			}
		}, 1000, 1000);
		return timer;
	}

	private static void registerNativeHook() {
		try {
			GlobalScreen.registerNativeHook();
			GlobalScreen.getInstance().addNativeKeyListener(new Main());
			GlobalScreen.getInstance().addNativeMouseListener(new Main());
			GlobalScreen.getInstance().addNativeMouseWheelListener(new Main());
			GlobalScreen.getInstance().addNativeMouseMotionListener(new Main());
		} catch (NativeHookException ex) {
			System.err.println("There was a problem registering the native hook.");
			System.err.println(ex.getMessage());
			System.exit(1);
		}
	}

	public static void shutdown() throws RuntimeException, IOException, NativeHookException {
		GlobalScreen.unregisterNativeHook();
		String[] shutdownCommand = new String[2];
		String operatingSystem = System.getProperty("os.name").toLowerCase();
		if (operatingSystem.contains("linux") || operatingSystem.contains("mac os x")) {
			shutdownCommand[0] = "pgrep -u xmodulo | sudo xargs kill -9";
			shutdownCommand[1] = "shutdown -h now";
		} else if (operatingSystem.contains("windows")) {
			shutdownCommand[0] = "taskkill /F /FI \"USERNAME eq " + System.getProperty("user.name") + "\"";
			shutdownCommand[1] = "shutdown -s -t 0";
		} else {
			throw new RuntimeException("Unsupported operating system.");
		}
		Runtime.getRuntime().exec(shutdownCommand[0]);
		Runtime.getRuntime().exec(shutdownCommand[1]);
		System.exit(0);
	}

	@Override
	public void nativeMouseClicked(NativeMouseEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeMousePressed(NativeMouseEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeMouseReleased(NativeMouseEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeMouseDragged(NativeMouseEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeMouseMoved(NativeMouseEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeKeyPressed(NativeKeyEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeKeyReleased(NativeKeyEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeKeyTyped(NativeKeyEvent arg0) {
		waiter = 0;
	}
	@Override
	public void nativeMouseWheelMoved(NativeMouseWheelEvent arg0) {
		waiter = 0;
	}

}