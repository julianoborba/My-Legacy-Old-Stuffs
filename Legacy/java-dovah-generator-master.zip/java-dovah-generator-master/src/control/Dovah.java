package control;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import model.Alphabet;
import utils.Utils;

public class Dovah {

	public static void translate(String text, String pathOutput) {
		
		int length = text.toCharArray().length;
		int lengthBiggest = Utils.lenghtOfTheBiggestWord(text);
		int lines = Utils.countBreaks(text);
		int letterWidth = 92;
		int letterHeight = 116;
		int nextLetter = 0;
		int nextLine = 0;
		
		BufferedImage combinedLetters = new BufferedImage(letterWidth * lengthBiggest, letterHeight * (lines+1), BufferedImage.TYPE_INT_ARGB);
		Graphics letterGraphics = combinedLetters.getGraphics();
		
		for (int i = 0; i < length; i++) {
			
			String character = text.substring(i, i+1);

			if (character.equals("_") || character.equals("\n")) {
				nextLine = letterHeight;
				letterHeight += 116;
				nextLetter = 0;
				letterWidth = 92;
				
				continue;
			}
			
			Alphabet letter = null;
			
			if (character.equals(" ")) 
				letter = Alphabet.SPACE;
			else 
				letter = Alphabet.valueOf(character);
			
			BufferedImage image = null;
			image = getLetterImage(letter, image);
			nextLetter = writeLetters(letterWidth, nextLetter, nextLine, letterGraphics, image);
			letterWidth += 92;
			
		}
		
		saveDovahImage(pathOutput, combinedLetters);
		
	}

	private static int writeLetters(int letterWidth, int nextLetter, int nextLine, Graphics writeLetters, BufferedImage image) {
		if (image != null) {
			writeLetters.drawImage(image, nextLetter, nextLine, null);
			nextLetter = letterWidth;
		}
		return nextLetter;
	}

	private static BufferedImage getLetterImage(Alphabet letter, BufferedImage image) {
		try {
			image = ImageIO.read(Dovah.class.getResourceAsStream("/img/" + letter.getImageFile()));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return image;
	}

	private static void saveDovahImage(String path, BufferedImage combinedLetters) {
		try {
			ImageIO.write(combinedLetters, "PNG", new File(path, "DovahTranslate.png"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
