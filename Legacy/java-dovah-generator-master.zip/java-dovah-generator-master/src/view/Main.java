package view;

import java.util.Scanner;

import javax.swing.filechooser.FileSystemView;

import control.Dovah;

public class Main {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Escreva seu texto:");
		String text = sc.nextLine();
		
		FileSystemView filesys = FileSystemView.getFileSystemView();
		// File[] roots = filesys.getRoots();
		Dovah.translate(text, filesys.getHomeDirectory().getPath());
		
	}

}
