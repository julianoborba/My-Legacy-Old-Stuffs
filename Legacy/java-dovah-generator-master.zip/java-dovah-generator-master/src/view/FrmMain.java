package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.filechooser.FileSystemView;

import control.Dovah;

public class FrmMain extends JFrame {
	
	private static final long serialVersionUID = 7116845702666896682L;

	public FrmMain() {
		
		setLayout(null);
		setSize(510, 560);
		setLocation(100, 100);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Dovah");
		
		final JTextArea txtTexto = new JTextArea();
		txtTexto.setSize(480, 480);
		txtTexto.setLocation(10, 10);
		
		JButton btnTraduzir = new JButton();
		btnTraduzir.setText("Traduzir");
		btnTraduzir.setSize(200, 30);
		btnTraduzir.setLocation(10, 490);
		btnTraduzir.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				FileSystemView filesys = FileSystemView.getFileSystemView();
				// File[] roots = filesys.getRoots();
				Dovah.translate(txtTexto.getText(), filesys.getHomeDirectory().getPath());
			}
		});
		
		add(txtTexto);
		add(btnTraduzir);
		
		setVisible(true);
	}

	public static void main(String[] args) {
		new FrmMain();
	}

}
