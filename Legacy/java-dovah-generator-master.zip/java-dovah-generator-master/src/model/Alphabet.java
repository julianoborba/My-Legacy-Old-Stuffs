package model;

public enum Alphabet {
	
	A("A.png"),
	B("B.png"),
	C("C.png"),
	D("D.png"),
	E("E.png"),
	F("F.png"),
	G("G.png"),
	H("H.png"),
	I("I.png"),
	J("J.png"),
	K("K.png"),
	L("L.png"),
	M("M.png"),
	N("N.png"),
	O("O.png"),
	P("P.png"),
	Q("Q.png"),
	R("R.png"),
	S("S.png"),
	T("T.png"),
	U("U.png"),
	V("V.png"),
	W("W.png"),
	X("X.png"),
	Y("Y.png"),
	Z("Z.png"),
	
	SPACE("SPACE.png"),
	FILLER("FILLER.png"),
	
	a("A.png"),
	b("B.png"),
	c("C.png"),
	d("D.png"),
	e("E.png"),
	f("F.png"),
	g("G.png"),
	h("H.png"),
	i("I.png"),
	j("J.png"),
	k("K.png"),
	l("L.png"),
	m("M.png"),
	n("N.png"),
	o("O.png"),
	p("P.png"),
	q("Q.png"),
	r("R.png"),
	s("S.png"),
	t("T.png"),
	u("U.png"),
	v("V.png"),
	w("W.png"),
	x("X.png"),
	y("Y.png"),
	z("Z.png");
	
	private String value;

	private Alphabet(String value) {
		this.value = value;
	}
	
	public String getImageFile() {
		return value;
	}

}
