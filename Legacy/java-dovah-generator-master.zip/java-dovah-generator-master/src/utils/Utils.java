package utils;

public class Utils {
	
	// Break lines
	public static final char BREAK1 = '_';
	public static final char BREAK2 = '\n';

	public static int countBreaks(String text) {
		int counter = 0;
		for (int i = 0; i < text.length(); i++)
			if (text.charAt(i) == BREAK1 || text.charAt(i) == BREAK2)
				counter++;
		return counter;
	}

	public static int lenghtOfTheBiggestWord(String text) {
		int temp = 0;
		int biggest = 0;
		for (int i = 0; i < text.length(); i++) {
			if (text.charAt(i) == BREAK1 || text.charAt(i) == BREAK2) {
				biggest = (biggest >= temp ? biggest : temp);
				temp = 0;
			} else {
				temp++;
			}
		}
		biggest = (biggest >= temp ? biggest : temp);
		return biggest;
	}

}
