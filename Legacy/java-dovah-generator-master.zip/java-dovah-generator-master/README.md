java-dovah-generator
====================

Updating legacy stuff :D
