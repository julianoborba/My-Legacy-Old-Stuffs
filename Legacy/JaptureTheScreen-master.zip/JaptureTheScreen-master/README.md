** From the legacy stuff along my way as Java programmer **


JaptureTheScreen
================

My Java version of the most util and simple and favorite tool of many developers.

The Capture The Screen tool (CTS) is a nice piece of software to get fast sequential screenshots, perfect for QA evidences, create documents like a manual or test case and more.

My Java version brings the same function but with some bugfixes and some extra flexibility. Is kinda my tribute to the developer of CTS.
