package br.juliano.view;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.jnativehook.GlobalScreen;
import org.jnativehook.NativeHookException;
import org.jnativehook.keyboard.NativeKeyEvent;
import org.jnativehook.keyboard.NativeKeyListener;
import org.jnativehook.mouse.NativeMouseEvent;
import org.jnativehook.mouse.NativeMouseInputListener;

public final class Window extends JFrame implements NativeKeyListener, NativeMouseInputListener  {

	private static final long serialVersionUID = 1L;

	private final JFileChooser chooser = new JFileChooser();
	private final JButton saveTo = new JButton("Save to...");
	private final JButton activate = new JButton("Activate");
	private final JButton deactivate = new JButton("Deactivate");
	private final JLabel path = new JLabel("");
	private final JLabel info = new JLabel("Images will be save like this: \"image0.png\", \"image1.png\".");
	private final JLabel tip = new JLabel("Click with mouse to capture images.");
	private final JTextField fileName = new JTextField("image");
	private final JComboBox<String> fileType = new JComboBox<String>(new String[] { "png", "bmp", "jpeg" });
	
	private int counter = 0;

	public Window() {

		registerNativeHook();
		final Window thiz = this;
		setupWindow();
		configureElements(thiz);
		setupElements();
		
	}

	private void configureElements(final Window thiz) {
		
		chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		saveTo.setBounds(10, 10, 100, 25);
		saveTo.addActionListener(addActionListener(thiz));
		path.setBounds(120, 10, 300, 25);
		fileName.setBounds(440, 10, 100, 25);
		fileType.setBounds(560, 10, 100, 25);
		info.setBounds(15, 45, 500, 25);
		activate.setBounds(10, 100, 100, 25);
		activate.addActionListener(activateActionListener(thiz));
		deactivate.setBounds(120, 100, 100, 25);
		deactivate.addActionListener(deactivateActionListener(thiz));
		deactivate.setEnabled(false);
		tip.setBounds(240, 100, 300, 25);
		
	}

	private void setupElements() {
		
		this.add(saveTo);
		this.add(chooser);
		this.add(activate);
		this.add(deactivate);
		this.add(path);
		this.add(fileName);
		this.add(fileType);
		this.add(info);
		this.add(tip);
		this.setVisible(true);
		
	}

	private ActionListener deactivateActionListener(final Window thiz) {
		
		return new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				activate.setEnabled(true);
				deactivate.setEnabled(false);
				GlobalScreen.getInstance().removeNativeKeyListener(thiz);
				GlobalScreen.getInstance().removeNativeMouseListener(thiz);
				GlobalScreen.getInstance().removeNativeMouseMotionListener(thiz);
			}
		};
		
	}

	private ActionListener activateActionListener(final Window thiz) {
		
		return new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				deactivate.setEnabled(true);
				activate.setEnabled(false);
				GlobalScreen.getInstance().addNativeKeyListener(thiz);
				GlobalScreen.getInstance().addNativeMouseListener(thiz);
				GlobalScreen.getInstance().addNativeMouseMotionListener(thiz);
			}
		};
		
	}

	private ActionListener addActionListener(final Window thiz) {
		
		return new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				chooser.showOpenDialog(thiz);
				path.setText(chooser.getSelectedFile().getAbsolutePath());
			}
		};
		
	}

	private void setupWindow() {
		
		this.setBounds(100, 100, 680, 165);
		this.setLayout(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("Japture The Screen");
		
	}

	private void registerNativeHook() {
		
		try {
			GlobalScreen.registerNativeHook();
		} catch (NativeHookException ex) {
			System.err.println("There was a problem registering the native hook.");
			System.err.println(ex.getMessage());
			System.exit(1);
		}
		
	}

	@Override
	public void nativeKeyPressed(NativeKeyEvent nke) {
	}

	@Override
	public void nativeKeyReleased(NativeKeyEvent nke) {
	}

	@Override
	public void nativeKeyTyped(NativeKeyEvent nke) {
		
//		if (nke.getRawCode() == 67 /*C*/ && !path.getText().equals("")) { 
//			String separator = System.getProperty("file.separator");
//			String type = (String) fileType.getSelectedItem();
//			Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
//		    BufferedImage image = null;
//		    try {
//		        image = new Robot().createScreenCapture(screenRect);
//		        File folderToSave = new File(path.getText() + separator + fileName.getText() + counter + "." + type);
//		        ImageIO.write(image, type, folderToSave);
//		    } catch (AWTException | IOException ex) {
//				System.err.println("There was a problem capturing the screen image.");
//				System.err.println(ex.getMessage());
//			}
//		    counter++;
//		}
		
	}

	@Override
	public void nativeMouseClicked(NativeMouseEvent arg0) {
		
		String separator = System.getProperty("file.separator");
		String type = (String) fileType.getSelectedItem();
		Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
	    BufferedImage image = null;
	    try {
	        image = new Robot().createScreenCapture(screenRect);
	        File folderToSave = new File(path.getText() + separator + fileName.getText() + counter + "." + type);
	        ImageIO.write(image, type, folderToSave);
	    } catch (AWTException | IOException ex) {
			System.err.println("There was a problem capturing the screen image.");
			System.err.println(ex.getMessage());
		}
	    counter++;
	    
	}

	@Override
	public void nativeMousePressed(NativeMouseEvent arg0) {
		
	}

	@Override
	public void nativeMouseReleased(NativeMouseEvent arg0) {
		
	}

	@Override
	public void nativeMouseDragged(NativeMouseEvent arg0) {
		
	}

	@Override
	public void nativeMouseMoved(NativeMouseEvent arg0) {
	}
	
}