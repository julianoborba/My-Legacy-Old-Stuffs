** From the legacy stuff along my way as Java programmer **

MyBluCon
========

It is an app inspirated by Bluetooth Keyboard Easy Connect (thanks Mike! See Mike's app at http://forum.xda-developers.com/showthread.php?t=925474). It have the same function to connect bluetooth devices, but not only HID devices, and isn't a service, is like an extension. You pair the device, and if the device don't connect, you open MyBluCon and select the device to connect and tap connect. Simple!

* 0 - Turn on Bluetooth on your Android;
* 1 - Pair your device with your Android;
* 2 - Open the application MyBluCon;
* 3 - If your Android does not have the necessary system files, the app will install, just wait - is needed allow superuser (aka root) and have Busybox installed;
* 4 - Your device once paired are listed on the screen, see its name and its index ([1], for example);
* 5 - In the edit box, type the index number of the device you want to connect (1, for example);
* 6 - Click "Connect my device";
* 7 - Wait and done!;
* 8 - When you are finished using the device you can disconnect it from the app, for some button on the device itself or simply turn off Bluetooth.

OBS.: On your system, even with the device connected you will see "paired but not connected", because this app don't update the status on labels.
