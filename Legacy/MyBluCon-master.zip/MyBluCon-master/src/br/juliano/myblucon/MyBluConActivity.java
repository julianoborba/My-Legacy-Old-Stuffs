package br.juliano.myblucon;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.text.SpannableString;
import android.text.method.ScrollingMovementMethod;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MyBluConActivity extends Activity {

	private BluetoothAdapter bluetoothAdapter;
	private Button btnConnect;
	private Button btnDisconnect;
	private Button btnRefresh;
	private TextView lblDevices;
	private boolean mExternalStorageAvailable;
	private boolean mExternalStorageWriteable;
	private MyBluConActivity myBluActivity;
	private EditText txtAddress;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		try {

			myBluActivity = this;
			btnDisconnect = ((Button) findViewById(R.id.btnDisconnect));
			btnConnect = ((Button) findViewById(R.id.btnConnect));
			btnRefresh = ((Button) findViewById(R.id.btnRefresh));
			lblDevices = ((TextView) findViewById(R.id.lblDevices));
			txtAddress = ((EditText) findViewById(R.id.txtAddress));
			lblDevices.setMovementMethod(new ScrollingMovementMethod());
			lblDevices.setScrollbarFadingEnabled(true);
			bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
			lblDevices.setTextColor(Color.rgb(59, 185, 255));

			String requiredDrivers = "";
			if (!new File("/system/xbin/hciconfig").exists()) {
				ensureFile(R.raw.hciconfig, "hciconfig");
				requiredDrivers += "hciconfig, ";
			}
			if (!new File("/system/xbin/hcitool").exists()) {
				ensureFile(R.raw.hcitool, "hcitool");
				requiredDrivers += "hcitool, ";
			}
			if (!new File("/system/xbin/hidd").exists()) {
				ensureFile(R.raw.hidd, "hidd");
				requiredDrivers += "hidd, ";
			}
			if (!requiredDrivers.equals("")) {
				Toast.makeText(this, requiredDrivers.lastIndexOf(",") + "have been installed!", Toast.LENGTH_SHORT).show();
			}
			
			if (bluetoothAdapter == null) {
				Toast.makeText(myBluActivity, "No device detected or Bluetooth is off.", Toast.LENGTH_LONG).show();
			} else {
				if (bluetoothAdapter.getState() != BluetoothAdapter.STATE_ON) {
					Toast.makeText(myBluActivity, "Bluetooth is switched off.", Toast.LENGTH_SHORT).show();
				} else {
					int i = 1;
					final HashMap<Integer, String> map = new HashMap<Integer, String>();
					Iterator<BluetoothDevice> localIterator = bluetoothAdapter.getBondedDevices().iterator();
					while (localIterator.hasNext()) {
						appendData(map, Integer.valueOf(i), localIterator);
						i++;
					}
					myBluActivity.btnConnect.setOnClickListener(new View.OnClickListener() {
						public void onClick(View paramView) {
							String str1 = txtAddress.getText().toString();
							String str2 = "";
							try {
								if (map.size() - Integer.valueOf(Integer.parseInt(str1)) < 0) {
									return;
								}
								str2 = (String) map.get(Integer.valueOf(Integer.parseInt(str1)));
							} catch (Exception localException) {
								Log.e("MyBluActivity.btnConnect.setOnClickListener():", " " + localException.getMessage());
								return;
							}
							if (str2.equals("")) {
								return;
							}
							String str3 = "hidd --connect " + str2;
							try {
								CmdTask localCmdTask = new CmdTask();
								localCmdTask.execute(new String[] { str3 });
							} catch (Exception localException) {
								Log.e("MyBluActivity.btnConnect.setOnClickListener():", " " + localException.getMessage());
							}
						}
					});
					myBluActivity.btnDisconnect.setOnClickListener(new View.OnClickListener() {
						public void onClick(View paramView) {
							String str1 = txtAddress.getText().toString();
							String str2 = "";
							try {
								if (map.size() - Integer.valueOf(Integer.parseInt(str1)) < 0) {
									return;
								}
								str2 = (String) map.get(Integer.valueOf(Integer.parseInt(str1)));
							} catch (Exception localException) {
								Log.e("MyBluActivity.btnConnect.setOnClickListener():", " " + localException.getMessage());
								return;
							}
							if (str2.equals("")) {
								return;
							}
							String str3 = "hidd --kill " + str2;
							try {
								CmdTask localCmdTask = new CmdTask();
								localCmdTask.execute(new String[] { str3 });
							} catch (Exception localException) {
								Log.e("MyBluActivity.btnDisconnect.setOnClickListener():", " " + localException.getMessage());
							}
						}
					});
					myBluActivity.btnRefresh.setOnClickListener(new View.OnClickListener() {
						public void onClick(View paramView) {
							if (bluetoothAdapter == null) {
								Toast.makeText(myBluActivity, "No device detected or Bluetooth is off.", Toast.LENGTH_LONG).show();
								return;
							} else if (bluetoothAdapter.getState() != BluetoothAdapter.STATE_ON) {
								Toast.makeText(myBluActivity, "Bluetooth is switched off.", Toast.LENGTH_SHORT).show();
								return;
							}
							lblDevices.setText("");
							HashMap<Integer, String> map = new HashMap<Integer, String>();
							int i = 1;
							Iterator<BluetoothDevice> localIterator = bluetoothAdapter.getBondedDevices().iterator();
							while (localIterator.hasNext()) {
								appendData(map, Integer.valueOf(i), localIterator);
								i++;
							}
						}
					});
				}
			}
		} catch (Exception exception) {
			Log.e("MyBluActivity.onCreate():", " " + exception.getMessage());
		}
	}

	private void appendData(Map<Integer, String> paramMap, Integer paramInteger, Iterator<BluetoothDevice> paramIterator) {
		BluetoothDevice localBluetoothDevice = (BluetoothDevice) paramIterator.next();
		String str1 = localBluetoothDevice.getName();
		String str2 = localBluetoothDevice.getAddress();
		ImageSpan localImageSpan = null;
		int majorDeviceClass = localBluetoothDevice.getBluetoothClass().getMajorDeviceClass();
		switch (majorDeviceClass) {
			case 1280:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.keyboard_mouse, 1);
				break;
			case 1024:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.headphone, 1);
				break;
			case 256:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.computer, 1);
				break;
			case 2304:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.engine, 1);
				break;
			case 1536:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.image, 1);
				break;
			case 0:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.search, 1);
				break;
			case 768:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.network, 1);
				break;
			case 512:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.mobile, 1);
				break;
			case 2048:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.toy, 1);
				break;
			case 7936:
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.unknown, 1);
				break;
			case 1792: // != ?
				localImageSpan = new ImageSpan(getApplicationContext(), R.drawable.wearable, 1);
		} 
		if (str1 == null || str1.equals("")) {
			str1 = "<no name>";
		}
		if (str2 == null || str2.equals("")) {
			str2 = "<no address>";
		}
		this.lblDevices.append("\n[" + paramInteger + "] ---------------------------------\n");
		this.lblDevices.append("\t\t" + str1 + "\n\t\t" + str2);
		SpannableString localSpannableString = new SpannableString("         ");
		localSpannableString.setSpan(localImageSpan, -1 + localSpannableString.length(), localSpannableString.length(), 17);
		this.lblDevices.append(localSpannableString);
		this.lblDevices.append("\n------------------------------------\n");
		paramMap.put(paramInteger, str2);
	}

	private void ensureFile(int paramInt, String paramString) {
		String str1 = "<sdcard not available>" + paramString;
		String str2 = "/system/xbin/" + paramString;
		try {
			updateExternalStorageState();
			if (this.mExternalStorageWriteable) {
				str1 = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + paramString;
			}
			Log.i(toString(), "MyBluActivity.ensureFile(int id, String file): File not found: " + str2);
			InputStream localInputStream = getResources().openRawResource(paramInt);
			byte[] arrayOfByte = new byte[localInputStream.available()];
			localInputStream.read(arrayOfByte);
			localInputStream.close();
			FileOutputStream localFileOutputStream = new FileOutputStream(str1);
			localFileOutputStream.write(arrayOfByte);
			localFileOutputStream.close();
			execCommandLine("mount -o rw,remount /system");
			execCommandLine("cp " + str1 + " " + str2);
			execCommandLine("rm " + str1);
		} catch (IOException localIOException) {
			Toast.makeText(this, "This application needs root permissions and BusyBox!", Toast.LENGTH_LONG).show();
		}
	}

	private int execCommandLine(String paramString) {
		int i = 0;
		try {
			Process localProcess = Runtime.getRuntime().exec("su");
			DataOutputStream localDataOutputStream = new DataOutputStream(localProcess.getOutputStream());
			if (paramString != null && !paramString.equals("")) {
				localDataOutputStream.writeBytes(paramString + "\n");
				localDataOutputStream.writeBytes("exit\n");
				localDataOutputStream.flush();
			}
			i = localProcess.waitFor();
			localDataOutputStream.close();
		} catch (IOException localIOException) {
			Log.e("MyBluActivity.execCommandLine(String paramString):", " " + localIOException.getMessage());
		} catch (InterruptedException interruptedException) {
			Log.e("MyBluActivity.execCommandLine(String paramString):", " " + interruptedException.getMessage());
		}
		return i;
	}

	private void updateExternalStorageState() {
		String str = Environment.getExternalStorageState();
		if ("mounted".equals(str)) {
			mExternalStorageWriteable = true;
			mExternalStorageAvailable = true;
		}
		if ("mounted_ro".equals(str)) {
			mExternalStorageAvailable = true;
			mExternalStorageWriteable = false;
		}
		mExternalStorageWriteable = false;
		mExternalStorageAvailable = false;
	}

	private class CmdTask extends AsyncTask<String, Void, Integer> {
		protected ProgressDialog dialog;

		private CmdTask() {
		}

		protected Integer doInBackground(String... paramArrayOfString) {
			String str = paramArrayOfString[0];
			Log.i("CmdTask.doInBackground(String... param):", str);
			int i = 0;
			while ((execCommandLine(str) != 0) && (i < 3)) {
				try {
					Log.i(toString(), "CmdTask.doInBackground(String... param): exit command is not equal zero... attempt " + i);
					Thread.sleep(1000);
					i++;
				} catch (InterruptedException localInterruptedException) {
					Log.e("CmdTask.doInBackground(String... paramArrayOfString) error:", " " + localInterruptedException.getMessage());
				}
			}
			return i;
		}

		protected void onPostExecute(Integer paramInteger) {
			try {
				this.dialog.dismiss();
				if (paramInteger.intValue() > 2) {
					Toast.makeText(myBluActivity, "Device busy, off or out of range!", Toast.LENGTH_SHORT).show();
				}
			} catch (Exception localException) {
				Log.e("CmdTask.onPostExecute(Integer result) error:", " " + localException.getMessage());
			}
		}

		protected void onPreExecute() {
			try {
				this.dialog = ProgressDialog.show(myBluActivity, "", "Please wait...", true);
			} catch (Exception localException) {
				Log.e("CmdTask.onPreExecute() error:", " " + localException.getMessage());
			}
		}
	}
}