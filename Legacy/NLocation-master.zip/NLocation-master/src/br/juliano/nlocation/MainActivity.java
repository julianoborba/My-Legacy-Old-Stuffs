package br.juliano.nlocation;

import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.graphics.Color;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private Timer myTimer;
	private boolean isStarted;
	private Handler handler;
	
	class MyTimerTask extends TimerTask {
		
		private EditText tel;
		
		public MyTimerTask(EditText tel) {
			this.tel = tel;
		}

		public void run() {
			handler.postDelayed(new Runnable() {
				public void run() {
					try {
						double[] latLon = getGPSLocation();
						sendSMS(tel.getText().toString(), "[NLocation]http://maps.google.com/maps?z=16&t=m&q=loc:" + latLon[0] + "+" + latLon[1]);
					} catch (Exception e) {
						Log.e("NLocation", "Erro : " + e.getMessage());
					}
				}
			}, 10);
		}
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		handler = new Handler(Looper.getMainLooper());
		final EditText tel = (EditText) findViewById(R.id.txtTel);
		final TextView isActive = (TextView) findViewById(R.id.lblIsActive);
		final Button btnStart = (Button) findViewById(R.id.btnStart);
		final Button btnStop = (Button) findViewById(R.id.btnStop);
		isActive.setTextColor(Color.RED);
		btnStop.setEnabled(false);
		btnStart.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if (!isStarted) {
					if (!tel.getText().toString().equals("")) {
						myTimer = new Timer();
						myTimer.schedule(new MyTimerTask(tel), 100, 15000);
						isStarted = true;
						btnStart.setEnabled(false);
						btnStop.setEnabled(true);
						tel.setEnabled(false);
						isActive.setText("Active");
						isActive.setTextColor(Color.BLUE);
					}
				}
			}
		});
		btnStop.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				if (isStarted) {
					if (myTimer != null) {
						myTimer.cancel();
						myTimer = null;
					}
					isStarted = false;
					btnStart.setEnabled(true);
					btnStop.setEnabled(false);
					tel.setEnabled(true);
					isActive.setText("Inactive");
					isActive.setTextColor(Color.RED);
				}
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private double[] getGPSLocation() {
	    LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
	    String bestProvider = LocationManager.GPS_PROVIDER;
	    Location location = locationManager.getLastKnownLocation(bestProvider);
	    LocationListener locListener = new LocationListener() {
	        public void onLocationChanged(Location l) {}
	        public void onProviderEnabled(String p) {}
	        public void onProviderDisabled(String p) {}
	        public void onStatusChanged(String p, int status, Bundle extras) {}
	    };
	    locationManager.requestLocationUpdates(bestProvider, 0, 0, locListener);
	    location = locationManager.getLastKnownLocation(bestProvider);
	    double lat = -1.0;
		double lon = -1.0;
		try {
	        lat = location.getLatitude();
	        lon = location.getLongitude();
	    } catch (NullPointerException e) {
	    	Log.e("NLocation", "Erro : " + e.getMessage());
	    }
		return new double[] { lat, lon };
	}

	private void sendSMS(String phoneNumber, String message) {
		SmsManager sms = SmsManager.getDefault();
		sms.sendTextMessage(phoneNumber, null, message, null, null);
	}
	
}