** From the legacy stuff along my way as Java programmer **
