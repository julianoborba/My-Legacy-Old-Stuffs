package br.com.juliano.machine;

import static org.junit.Assert.assertTrue;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.fasterxml.jackson.core.JsonProcessingException;

import br.com.juliano.machine.controller.UserController;
import br.com.juliano.machine.model.Login;
import br.com.juliano.machine.model.Phone;
import br.com.juliano.machine.model.User;

public class UserTest {

	@Test
	public void shouldCreateNewUser() throws JsonProcessingException {

		List<Phone> phones = new ArrayList<>();
		Phone phone = new Phone();
		phone.setDdd("21");
		phone.setNumber("987654321");
		phones.add(phone);
		User user = new User(UUID.randomUUID(), "email@email.com", "", null);
		user.setName("Joao da Silva");
		user.setPassword("hunter2");
		ResponseEntity<Serializable> responseEntity = new UserController().create(user);
		assertTrue(responseEntity.getStatusCode().compareTo(HttpStatus.CREATED) == 0);

	}
	
	@Test
	public void shouldAlertExistingEmail() throws JsonProcessingException {

		List<Phone> phones = new ArrayList<>();
		Phone phone = new Phone();
		phone.setDdd("21");
		phone.setNumber("987654321");
		phones.add(phone);
		User user = new User(UUID.randomUUID(), "email@email.com", "", null);
		user.setName("Joao da Silva");
		user.setPassword("hunter2");
		ResponseEntity<Serializable> responseEntity = new UserController().create(user);
		assertTrue(responseEntity.getStatusCode().compareTo(HttpStatus.BAD_REQUEST) == 0);

	}
	
	@Test
	public void shouldLogin() throws JsonProcessingException {

		Login login = new Login();
		login.setEmail("email@email.com");
		login.setPassword("hunter2");
		ResponseEntity<Serializable> responseEntity = new UserController().login(login.getEmail(), login.getPassword());
		assertTrue(responseEntity.getStatusCode().compareTo(HttpStatus.OK) == 0);

	}
	
//	@Test
//	public void shouldBan() throws JsonProcessingException {
//
//		Login login = new Login();
//		login.setEmail("email@email.com");
//		login.setPassword("hunter3");
//		ResponseEntity<Serializable> responseEntity = new UserController().login(login.getEmail(), login.getPassword());
//		assertTrue(responseEntity.getStatusCode().compareTo(HttpStatus.UNAUTHORIZED) == 0);
//
//	}
	
	@Test
	public void shouldNotFind() throws JsonProcessingException {

		Login login = new Login();
		login.setEmail("emailololo@email.com");
		login.setPassword("hunter2");
		ResponseEntity<Serializable> responseEntity = new UserController().login(login.getEmail(), login.getPassword());
		assertTrue(responseEntity.getStatusCode().compareTo(HttpStatus.NOT_FOUND) == 0);

	}

}