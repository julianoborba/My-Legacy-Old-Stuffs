package br.com.juliano.machine.model;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "users")
public class User implements UserDetails {

	private static final long serialVersionUID = -4499439976461535778L;

	@Id
	@JsonIgnore
	@GeneratedValue
	private UUID id;

	@Column(name = "name")
	private String name;

	@Column(name = "email")
	private String email;

	@Column(name = "password")
	private String password;

	@OneToMany(fetch = FetchType.EAGER, targetEntity = Phone.class, mappedBy = "user", cascade = CascadeType.ALL)
	private List<Phone> phones; // TODO pq os phones nao estao sendo joinados quando consulto eles? Y-Y

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "created", length = 10)
	private Date created = new Date();

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "modified", length = 10)
	private Date modified;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_login", length = 10)
	private Date last_login;

	@Column(name = "token")
	private String token;
	
	@JsonIgnore
	@Transient
	private String role;

	@Transient
	@JsonIgnore
	private Collection<? extends GrantedAuthority> authorities;

	public User() {
	}
	
	public User(UUID id, String email, String token, Collection<? extends GrantedAuthority> authorities) {
		this.id = id;
		this.email = email;
		this.token = token;
		this.authorities = authorities;
	}
	
	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Phone> getPhones() {
		return phones;
	}

	public void setPhones(List<Phone> phones) {
		this.phones = phones;
	}

	public Date getCreated() {
		return created;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public Date getModified() {
		return modified;
	}

	public void setModified(Date modified) {
		this.modified = modified;
	}

	public Date getLast_login() {
		return last_login;
	}

	public void setLast_login(Date last_login) {
		this.last_login = last_login;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	@Transient
	@JsonIgnore
	public String getRole() {
		return role;
	}

	@Transient
	@JsonIgnore
	public void setRole(String role) {
		this.role = role;
	}
	
	@Transient
	@JsonIgnore
	@Override
	public String getUsername() {
		return this.email;
	}

	@Transient
	@JsonIgnore
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}

	@Transient
	@JsonIgnore
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}

	@Transient
	@JsonIgnore
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}

	@Transient
	@JsonIgnore
	@Override
	public boolean isEnabled() {
		return true;
	}

	@Transient
	@JsonIgnore
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return authorities;
	}
}