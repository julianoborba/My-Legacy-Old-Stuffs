package br.com.juliano.machine.jwt;

import br.com.juliano.machine.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

public class JwtTokenGenerator {

	public static String generateToken(User user, String secret) {
		Claims claims = Jwts.claims().setSubject(user.getUsername());
		claims.put("userId", user.getId() + "");
		claims.put("role", user.getRole());
		return Jwts.builder().setClaims(claims).signWith(SignatureAlgorithm.HS512, secret).compact();
	}

}