package br.com.juliano.machine.jwt;

import java.util.UUID;

import org.springframework.stereotype.Component;

import br.com.juliano.machine.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;

@Component
public class JwtTokenValidator {

	public User parseToken(String token) {
		User user = null;
		try {
			Claims claims = Jwts.parser().setSigningKey("hunter2").parseClaimsJws(token).getBody(); // TODO obter key do banco
			user = new User();
			user.setEmail(claims.getSubject());
			user.setId(UUID.fromString((String) claims.get("userId")));
			user.setRole((String) claims.get("role"));
		} catch (JwtException e) {
			e.printStackTrace();
		}
		return user;
	}
}