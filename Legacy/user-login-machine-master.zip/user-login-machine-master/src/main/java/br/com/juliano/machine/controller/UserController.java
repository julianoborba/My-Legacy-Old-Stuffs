package br.com.juliano.machine.controller;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.juliano.machine.jwt.JwtTokenGenerator;
import br.com.juliano.machine.model.ErrorMessage;
import br.com.juliano.machine.model.Login;
import br.com.juliano.machine.model.User;


@RestController
public class UserController {
	
	private SessionFactory sessionFactory;
	
	public UserController() {
		sessionFactory = new Configuration().configure().buildSessionFactory();
	}
	
	// TODO esses metodos estao enormes, preciso diminui-los...

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/users", method = RequestMethod.POST)
	public ResponseEntity<Serializable> create(@RequestBody User user) {
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("FROM User U WHERE U.email LIKE :email");
		query.setParameter ("email", user.getEmail());
		List<User> users = (List<User>) query.list();
		
		if (!users.isEmpty()) {
			session.getTransaction().commit();
			session.close();
			ErrorMessage errorMessage = new ErrorMessage("Usuario ja cadastrado na base com este e-mail.");
            return new ResponseEntity<>((Serializable) errorMessage, HttpStatus.BAD_REQUEST);
		}
		
		user.setPassword(hashMy(user.getPassword()));
		
		session.save(user);
		
		users = (List<User>) query.list();
		user = users.get(0);
		user.setRole("admin"); // TODO tornar dinamico, sera que rola fazer o hibernate gerar esses dados por anotation?
		String token = JwtTokenGenerator.generateToken(user, user.getPassword());
		user.setToken(hashMy(token));
		session.update(user);
		
		session.getTransaction().commit();
		session.close();
		return new ResponseEntity<>((Serializable) user, HttpStatus.CREATED);
		
	}
	
	private String hashMy(String password) {
		String passwordHashed = password;
		// TODO Criptogafia n�o revers�vel (hash) na senha e no token
		// https://crackstation.net/hashing-security.htm
		// The general workflow for account registration and authentication in a hash-based account system is as follows:
		//	    The user creates an account.
		//	    Their password is hashed and stored in the database. At no point is the plain-text (unencrypted) password ever written to the hard drive.
		//	    When the user attempts to login, the hash of the password they entered is checked against the hash of their real password (retrieved from the database).
		//	    If the hashes match, the user is granted access. If not, the user is told they entered invalid login credentials.
		//	    Steps 3 and 4 repeat everytime someone tries to login to their account.
		//	To Store a Password
		//	    Generate a long random salt using a CSPRNG.
		//	    Prepend the salt to the password and hash it with a standard password hashing function like Argon2, bcrypt, scrypt, or PBKDF2.
		//	    Save both the salt and the hash in the user's database record.
		//	To Validate a Password
		//	    Retrieve the user's salt and hash from the database.
		//	    Prepend the salt to the given password and hash it using the same hash function.
		//	    Compare the hash of the given password with the hash from the database. If they match, the password is correct. Otherwise, the password is incorrect.
		return passwordHashed;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/login", method = RequestMethod.GET) // TODO mudar pra path params, pq ja nao criei com path param antes??
	public ResponseEntity<Serializable> login(@RequestParam("email") String email, @RequestParam("password") String password) {
		
		Login login = new Login(email, password);
		
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		Query query = session.createQuery("FROM User U WHERE U.email LIKE :email");
		query.setParameter ("email", login.getEmail());
		List<User> users = (List<User>) query.list();
		
		if (users.isEmpty()) {
		
			session.getTransaction().commit();
			session.close();
			ErrorMessage errorMessage = new ErrorMessage("Usuario e/ou senha invalidos.");
            return new ResponseEntity<>((Serializable) errorMessage, HttpStatus.NOT_FOUND);
            
		} else if (!users.get(0).getPassword().equals(login.getPassword())) {
			
			session.getTransaction().commit();
			session.close();
			ErrorMessage errorMessage = new ErrorMessage("Usuario e/ou senha invalidos.");
            return new ResponseEntity<>((Serializable) errorMessage, HttpStatus.UNAUTHORIZED);
            
		}
		
		User user = users.get(0);
		user.setLast_login(new Date());
		session.update(user);
		session.getTransaction().commit();
		session.close();
		
		return new ResponseEntity<>((Serializable) user, HttpStatus.OK);
		
	}
	
}