package br.com.juliano.machine.model;

import java.io.Serializable;

public class ErrorMessage implements Serializable {
	
	private static final long serialVersionUID = -8538260855138713324L;

	private String message;
	
	public ErrorMessage(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}