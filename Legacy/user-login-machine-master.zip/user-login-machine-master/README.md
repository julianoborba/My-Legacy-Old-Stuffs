# user-login-machine
RESTfull user & login machine api for fun and maybe profit.

To begin, do the build thing then start Jetty via command line trough Gradle.

##### Windows:
	gradlew.bat build
	gradlew.bat jettyRun

or

##### Unix:
	./gradlew build
	./gradlew jettyRun

### Create

###### URL:
- http://localhost:8080/user-login-machine/users/

###### Content Type:
- application/json

###### Body:
	{
	   "name":"João da Silva",
	   "email":"joao@silva.org",
	   "password":"hunter2",
	   "phones":[
	      {
	         "number":"987654321",
	         "ddd":"21"
	      }
	   ]
	}

###### Verb:
- POST to create

### Login

###### URL:
- http://localhost:8080/user-login-machine/login?email=email&password=password

###### Content Type:
- application/json

## Token layout
Should go in HTTP HEADER...

	- Name: Authorization
	- Value: Bearer [generate token]
Like this:

	> Authorization - Bearer eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJqb2FvQHNpbHZhLm9yZyIsInVzZXJJZCI6Im51bGwifQ.88mn5UVnwvev848QSRDZcWhHMq3c0at8jrC7FTdUywBI7C-DQE9WbTWF9No43GCkAeNgQ3yK0kGm4dYFQQg2KQ

### Some...
... source code for initial setup for Jwt Web Token was "borrow" from
- here https://www.toptal.com/java/rest-security-with-jwt-spring-security-and-java
- and here https://pragmaticintegrator.wordpress.com/2016/05/27/validating-jwt-with-spring-boot-and-spring-security/

So... thanks! But in this repo, this is it a bit far from what I really wanna setup...
